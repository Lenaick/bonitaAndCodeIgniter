# bonita-php-client
An interface to Bonita BPM REST API in PHP
